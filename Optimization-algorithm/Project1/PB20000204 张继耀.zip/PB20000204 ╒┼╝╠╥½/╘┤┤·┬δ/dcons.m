function [dh,dg]=dcons(x) %dcons.m
dh=[1,1,1;2,-1,1];
dg=[];