function p=phi1(x,sigma)
f=f1(x); [h,g]=cons(x); gn=max(-g,0);
l0=length(h); m0=length(g);
if(l0==0), p=f+1.0/sigma*norm(gn,1); end
if(m0==0), p=f+1.0/sigma*norm(h,1); end
if(l0>0&m0>0)
p=f+1.0/sigma*(norm(h,1)+norm(gn,1));
end