function f=f1(x) %f1.m
f=x(1)^2+2*x(2)^2+x(3)^2-2*x(1)*x(2)+x(3);

