function df=df1(x) %df1.m
df=[2*x(1)-2*x(2),4*x(2)-2*x(1),2*x(3)+1]';