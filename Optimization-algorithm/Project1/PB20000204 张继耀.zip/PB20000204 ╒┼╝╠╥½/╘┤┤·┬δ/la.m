function l=la(x,mu,lam)
f=f1(x); 
[h,g]=cons(x); 
l0=lemgth(h); m0=length(g);
if(l0==0), l=f-lam*g; end
if(m0==0), l=f-mu'*h; end
if(l0>0&m0>0)
l=f-mu'*h-lam'*g;
end