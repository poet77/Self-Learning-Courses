function [h,g]=cons(x) %cons.m
h=[x(1)+x(2)+x(3)-4;2*x(1)-x(2)+x(3)-2];
g=[];