function dh=dah(ep,d,mu,lam,dfk,Bk,Ae,hk,Ai,gk)
n=length(dfk); l=length(hk); m=length(gk);
dh=zeros(n+l+m+1,1);
dh(1)=ep;
if(l>0&m>0)
dh(2:n+1)=Bk*d-Ae'*mu-Ai'*lam+dfk;
dh(n+2:n+l+1)=hk+Ae*d;
for(i=1:m)
   dh(n+l+1+i)=phi(ep,lam(i),gk(i)+Ai(i,:)*d);
end
end
if(l==0)
dh(2:n+1)=Bk*d-Ai'*lam+dfk;
for(i=1:m)
dh(n+1+i)=phi(ep,lam(i),gk(i)+Ai(i,:)*d);
end
end
if(m==0)
dh(2:n+1)=Bk*d-Ae'*mu+dfk;
dh(n+2:n+l+1)=hk+Ae*d;
end
dh=dh(:);

