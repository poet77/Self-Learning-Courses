function dl=dlax(x,mu,lam)
df=df1(x); 
[Ae,Ai]=dcons(x); 
[m1,m2]=size(Ai); 
[l1,l2]=size(Ae);
if(l1==0)
    dl=df-Ai'*lam; 
end

if(m1==0)
    dl=df-Ae'*mu; 
end

if(l1>0&m1>0) 
    dl=df-Ae'*mu-Ai'*lam; 
end