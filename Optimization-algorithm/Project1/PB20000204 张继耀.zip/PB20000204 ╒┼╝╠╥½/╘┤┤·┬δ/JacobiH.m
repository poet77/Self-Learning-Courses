function A=JacobiH(ep,d,mu,lam,dfk,Bk,Ae,hk,Ai,gk)
n=length(dfk); l=length(hk); m=length(gk);
A=zeros(n+l+m+1,n+l+m+1);

dd1=zeros(m,m); dd2=zeros(m,m); v1=zeros(m,1);
for(i=1:m)
fm=sqrt(lam(i)^2+(gk(i)+Ai(i,:)*d)^2+2*ep^2);
dd1(i,i)=1-lam(i)/fm;
dd2(i,i)=1-(gk(i)+Ai(i,:)*d)/fm;
v1(i)=-2*ep/fm;
end


if(l>0&m>0)
A=[1, zeros(1,n), zeros(1,l), zeros(1,m);
zeros(n,1), Bk, -Ae', -Ai';
zeros(l,1), Ae, zeros(l,l), zeros(l,m) ;
v1, dd2*Ai, zeros(m,l), dd1];
end
if(l==0)
A=[1, zeros(1,n), zeros(1,m);
zeros(n,1), Bk, -Ai';
v1, dd2*Ai, dd1];
end
if(m==0)
A=[1, zeros(1,n), zeros(1,l);
zeros(n,1), Bk, -Ae';
zeros(l,1), Ae, zeros(l,l)];
end