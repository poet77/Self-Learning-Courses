function p=phi(ep,a,b)
p=a+b-sqrt(a^2+b^2+2*ep^2);