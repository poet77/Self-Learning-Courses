function y=f(x)
y=sin(x);
end