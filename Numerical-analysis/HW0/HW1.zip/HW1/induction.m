function y=induction(phi,x)

y=(x*phi+1/(x+1))/(x+1);

end



















